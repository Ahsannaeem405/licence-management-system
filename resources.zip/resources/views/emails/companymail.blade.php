<!DOCTYPE html>
<html>
<head>

</head>
<body>
    <h1>{{ $details['email'] }}</h1>
    <p>Thank you</p>
</body>
</html>