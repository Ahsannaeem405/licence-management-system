<?php

return [
    'title' => 'Ceci est le titre en anglais.'
];
