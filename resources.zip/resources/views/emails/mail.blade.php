<!DOCTYPE html>
<html>
<head>
    <title> </title>
 
<body>
    <h1>Email:{{ $details['email'] }}</h1>
    <p>Password:{{ $details['password'] }}</p>
  <p>Login url:{{env('APP_URL')}}/login</p> 

   
   
</body>
</html>